﻿using ClassroomBooking.Configuration;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Web.Script.Serialization;

namespace ClassroomBooking.Services
{

    public class ConfigService
    {
        public AppSettings Load()
        {
            try
            {
                string path = Path.Combine(
                    AppDomain.CurrentDomain.BaseDirectory,
                    "appsettings.json");

                if (!File.Exists(path))
                    return new AppSettings();

                string json = File.ReadAllText(path);

                JavaScriptSerializer serializer =
                    new JavaScriptSerializer();

                AppSettings settings =
                    serializer.Deserialize<AppSettings>(json);

                return settings ?? new AppSettings();
            }
            catch
            {
                return new AppSettings();
            }

        }
    }

    public class ConfigServiceOLD
    {
        public AppSettings Load()
        {
            string path = Path.Combine(
                AppDomain.CurrentDomain.BaseDirectory,
                "appsettings.json");
            if (!File.Exists(path))
                return new AppSettings();

            string json = File.ReadAllText(path);

            JavaScriptSerializer serializer = 
                new JavaScriptSerializer();

            AppSettings settings =
                serializer.Deserialize<AppSettings>(json);

            return settings ?? new AppSettings();
        }
    }

}
