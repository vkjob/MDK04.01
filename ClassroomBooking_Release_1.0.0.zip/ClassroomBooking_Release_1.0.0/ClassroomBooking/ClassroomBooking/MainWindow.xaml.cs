﻿using ClassroomBooking.Models;
using ClassroomBooking.Services;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Windows;
using System.Windows.Controls;
using ClassroomBooking.Configuration;

namespace ClassroomBooking
{
    public partial class MainWindow : Window
    {
        private readonly UserService userService = new UserService();
        private readonly RoomService roomService = new RoomService();
        private readonly BookingService bookingService = new BookingService();
        private readonly ConfigService configService = new ConfigService();
        private AppSettings settings;

        public MainWindow()
        {
            InitializeComponent();

            UserComboBox.ItemsSource = userService.GetUsers();
            RoomComboBox.ItemsSource = roomService.GetRooms();
            BookingDatePicker.SelectedDate= DateTime.Today;
            settings = configService.Load();

            //Title = settings.AppTitle;
            Title = $"{settings.AppTitle} ({settings.OrganizationName})";
            StatusTextBlock.Text = settings.StatusMessage;
            StatusTextBlock.Text = settings.AdminMode ? "Режим администратора" : settings.StatusMessage;

            RefreshBookings();
        }

        private void BookButton_Click(object sender, RoutedEventArgs e)
        {
            if (!(UserComboBox.SelectedItem is User user))
            {
                StatusTextBlock.Text = "Выберите пользователя.";
                return;
            }
            
            if (!(RoomComboBox.SelectedItem is Room room))
            {
                StatusTextBlock.Text = "Выберите аудиторию.";
                return;
            }

            if (!(BookingDatePicker.SelectedDate is DateTime date))
            {
                StatusTextBlock.Text = "Выберите дату.";
                return;
            }

            if (!TimeSpan.TryParse(StartTimeTextBox.Text, out var startTime) ||
                !TimeSpan.TryParse(EndTimeTextBox.Text, out var endTime))
            {
                StatusTextBlock.Text = "Введите время в формате ЧЧ:ММ.";
                return;
            }

            TimeSpan workStart;
            TimeSpan workEnd;

            if (!TimeSpan.TryParse(settings.WorkDayStart, out workStart) ||
                !TimeSpan.TryParse(settings.WorkDayEnd, out workEnd))
            {
                StatusTextBlock.Text =
                    "Ошибка конфигурации рабочего времени.";
                return;
            }

            if (startTime < workStart || endTime > workEnd)
            {
                StatusTextBlock.Text =
                    "Бронирование достуно с " +
                    settings.WorkDayStart + " до " +
                    settings.WorkDayEnd + ".";
                return;
            }
            double duration = (endTime - startTime).TotalMinutes;

            if (duration < settings.MinBookingMinutes)
            {
                StatusTextBlock.Text = "Минимальная длительность - " + settings.MinBookingMinutes + " минут.";
                return;
            }

            if (duration > settings.MaxBookingHours * 60)
            {
                StatusTextBlock.Text = "Максимальная длительность — " + settings.MaxBookingHours + " ч.";
                return;
            }

            if (!settings.AllowPastDates && BookingDatePicker.SelectedDate.Value.Date < DateTime.Today)
            {
                StatusTextBlock.Text = "Бронирование на прошедшую дату запрещено.";
                return;
            }


            if (!room.IsAvailable && !settings.AllowUnavailableRooms)
            {
                StatusTextBlock.Text = "Выбранная аудитория недоступна для бронирования.";
                return;
            }

            if (startTime >= endTime)
            {
                StatusTextBlock.Text = "Время начала должно быть раньше времени окончания.";
                return;
            }

            var booking = new Booking()
            {
                UserId = user.Id,
                RoomId = room.Id,
                Date = date,
                StartTime = startTime,
                EndTime = endTime
            };

            //StatusTextBlock.Text = booking.UserId.ToString() + " " + booking.RoomId.ToString() + " " + booking.Date.ToString() + " " + booking.StartTime.ToString() + " " + booking.EndTime.ToString();
            
            if (!bookingService.AddBooking(booking))
            {
                StatusTextBlock.Text = "На это время аудитория уже забронирована.";
                return;
            }
            
            StatusTextBlock.Text = "Бронирование создано.";
            RefreshBookings();
        }

        private void RefreshBookings()
        {
            var rooms = roomService.GetRooms();
            var users = userService.GetUsers();

            var items = bookingService.GetBookings()
                .Select(x =>
                {
                    var user = users.FirstOrDefault(u => u.Id == x.UserId);
                    var room = rooms.FirstOrDefault(r => r.Id == x.RoomId);

                    return $"{x.Date: dd.MM.yyyy} | {x.StartTime:hh':'mm} - {x.EndTime:hh':'mm} | " + $"{room?.Number} | {user?.Name}";
                    //return $"{x.Date: dd.MM.yyyy} | " + $"{room?.Number} | {user?.Name}";
                })
                .ToList();
            BookingsListBox.ItemsSource = items;
        }
    }
}
